import { Component } from '@angular/core';

@Component({
  selector: 'app-placement',
  imports: [],
  templateUrl: './placement.component.html',
  styleUrl: './placement.component.css'
})
export class PlacementComponent {

}
